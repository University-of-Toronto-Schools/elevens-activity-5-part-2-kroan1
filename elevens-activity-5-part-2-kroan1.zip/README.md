[![Work in Repl.it](https://classroom.github.com/assets/work-in-replit-14baed9a392b3a25080506f3b7b6d57f295ec2978f6f33ec97e36a161684cbe9.svg)](https://classroom.github.com/online_ide?assignment_repo_id=2816999&assignment_repo_type=AssignmentRepo)
# elevens-activity-5-starter-code
Find and fix the bugs in the Deck class; use the "run" button and iterate until you get the message "All tests passed!"
